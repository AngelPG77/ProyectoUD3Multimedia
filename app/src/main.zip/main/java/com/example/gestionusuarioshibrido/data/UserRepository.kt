package com.example.gestionusuarioshibrido.data

import com.example.gestionusuarioshibrido.data.local.User
import com.example.gestionusuarioshibrido.data.local.UserDao
import com.example.gestionusuarioshibrido.data.local.toRemote
import com.example.gestionusuarioshibrido.data.remote.toLocal
import com.example.gestionusuarioshibrido.network.MockApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map


sealed class RepositoryResult {
    class Success(val message: String) : RepositoryResult()
    data class Error(val message: String, val exception: Throwable? = null) : RepositoryResult()
}


interface UserRepository {

    fun getAllUsersStream(): Flow<List<User>>

    suspend fun insertUser(user: User): RepositoryResult

    suspend fun updateUser(user: User): RepositoryResult

    suspend fun deleteUser(user: User): RepositoryResult

    // Sincronización
    suspend fun uploadPendingChanges(): RepositoryResult
    suspend fun syncFromServer(): RepositoryResult
}

class DefaultUserRepository(
    private val local: UserDao,
    private val remote: MockApiService
) : UserRepository {

    override fun getAllUsersStream(): Flow<List<User>> =
        local.getAllUsers().map { list -> list.filter { !it.pendingDelete } }

    override suspend fun insertUser(user: User): RepositoryResult =
        try {
            local.insertUser(user.copy(pendingSync = true))
            RepositoryResult.Success("Usuario insertado correctamente")
        } catch (e: Exception) {
            RepositoryResult.Error("Error insertando usuario", e)
        }

    override suspend fun updateUser(user: User): RepositoryResult =
        try {
            local.updateUser(user.copy(pendingSync = true))
            RepositoryResult.Success("Usuario modificado correctamente")
        } catch (e: Exception) {
            RepositoryResult.Error("Error modificando usuario", e)
        }


    override suspend fun deleteUser(user: User): RepositoryResult =
        try {
            local.updateUser(user.copy(pendingDelete = true,pendingSync = true))
            RepositoryResult.Success("Usuario borrado correctamente")
        } catch (e: Exception) {
            RepositoryResult.Error("Error borrando usuario", e)
        }

    override suspend fun uploadPendingChanges(): RepositoryResult {
        try {
            // Altas y modificaciones
            //--------------------------------------------
            val pendingUpdates = local.getPendingUpdates()
            pendingUpdates.forEach { user ->
                if (user.id.startsWith("local_")) {
                    // Crear usuario nuevo en remoto
                    val created = remote.createUser(user.toRemote())
                    local.deleteUser(user)
                    local.updateUser(created.toLocal())
                } else {
                    // Actualizar usuario en remoto
                    remote.updateUser(user.id, user.toRemote())
                    local.updateUser(user.copy(pendingSync = false))
                }
            }

            // Borrados
            //---------------------------------------------
            val pendingDeletes = local.getPendingDeletes()
            pendingDeletes.forEach { user ->
                if (!user.id.startsWith("local_")) {
                    remote.deleteUser(user.id)
                }
                local.deleteUser(user)
            }
            return RepositoryResult.Success("Sincronización correcta: " +
                                                      "\nLOCAL -> REMOTE \n" +
                                                      "${pendingUpdates.size} actualizados, ${pendingDeletes.size} borrados.")
        } catch (e: Exception) {
            return RepositoryResult.Error("Error sincronizando LOCAL -> REMOTE", e)
        }
    }

    override suspend fun syncFromServer(): RepositoryResult {
        try {
            val remoteUsers = remote.getAllUsers()
            val localIds = local.getUsersIds()
            val usersToInsert = remoteUsers.filter { !localIds.contains(it.id) }

            // Utilizamos la política de onConflict.REPLACE
            local.insertUsers(remoteUsers.map { it.toLocal() })
            return RepositoryResult.Success("Sincronización correcta: \n" +
                                                      "REMOTE -> LOCAL \n" +
                                                      "${usersToInsert.size} insertados y ${remoteUsers.size - usersToInsert.size} actualizados.")
        } catch (e: Exception) {
            return RepositoryResult.Error("Error sincronizando REMOTE -> LOCAL", e)
        }
    }
}
