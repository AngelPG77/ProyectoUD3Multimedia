package com.example.gestionusuarioshibrido.data

import android.content.Context
import com.example.gestionusuarioshibrido.data.local.UserDatabase
import com.example.gestionusuarioshibrido.network.MockApiService
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit

interface AppContainer {
    val userRepository: UserRepository
}
class AppDataContainer(private val context: Context) : AppContainer {

    private val baseUrlMockApi = "https://6921e89b512fb4140be1b800.mockapi.io/api/wirtz/"

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        explicitNulls = false
    }

    private val retrofitMockApi: Retrofit = Retrofit.Builder()
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .baseUrl(baseUrlMockApi)
        .build()

    private val retrofitMockApiService: MockApiService by lazy {
        retrofitMockApi.create(MockApiService::class.java)
    }

    override val userRepository: UserRepository by lazy {
        DefaultUserRepository(local = UserDatabase.getDatabase(context).userDao(),
                              remote = retrofitMockApiService)
    }
}