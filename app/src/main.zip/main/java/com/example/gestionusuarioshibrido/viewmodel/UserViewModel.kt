package com.example.gestionusuarioshibrido.viewmodel

import android.content.Context
import androidx.core.os.registerForAllProfilingResults
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.gestionusuarioshibrido.GestionUsuariosApplication
import com.example.gestionusuarioshibrido.data.RepositoryResult
import com.example.gestionusuarioshibrido.data.local.User
import com.example.gestionusuarioshibrido.data.UserRepository
import com.example.gestionusuarioshibrido.data.testUsers
import com.example.gestionusuarioshibrido.sensors.ShakeUserCoordinator
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class UserViewModel(private val userRepository: UserRepository) : ViewModel() {
    // Canal de eventos para la UI (mensajes tipo Toast/SnackBar)
    private val _events = Channel<String>()
    // La UI lo observará
    val events = _events.receiveAsFlow()
    private var usersAddedCount = 0
    private var shakeUserCoordinator: ShakeUserCoordinator? = null

    val users: StateFlow<List<User>> = userRepository.getAllUsersStream()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    fun insertUser(user: User) = viewModelScope.launch {
        processResult(userRepository.insertUser(user))
    }

    fun updateUser(user: User) = viewModelScope.launch {
        processResult(userRepository.updateUser(user))
    }

    fun deleteUser(user: User) = viewModelScope.launch {
        processResult(userRepository.deleteUser(user))
    }

    fun setupShakeListener(context: Context) {
        if (shakeUserCoordinator == null) {
            shakeUserCoordinator = ShakeUserCoordinator(context, this)
            shakeUserCoordinator?.startListening()
        }
    }

    override fun onCleared() {
        super.onCleared()
        shakeUserCoordinator?.stopListening()
    }

    fun addTestUser() = viewModelScope.launch {
        if (usersAddedCount < testUsers.size) {
            val addedUser = testUsers[usersAddedCount]

            userRepository.insertUser(addedUser)
            usersAddedCount++

            _events.send(
                "Usuario ${addedUser.firstName} ${addedUser.lastName} de prueba añadido. Quedan ${testUsers.size - usersAddedCount}."
            )

        } else {
            _events.send("¡No quedan más usuarios de prueba para añadir!")
        }
    }


    fun sync() = viewModelScope.launch {
        processResult(userRepository.uploadPendingChanges())
        processResult(userRepository.syncFromServer())
    }


    private suspend fun processResult(result: RepositoryResult) {
        when (result) {
            is RepositoryResult.Success ->
                _events.send(result.message)

            is RepositoryResult.Error ->
                _events.send("${result.message} ${result.exception?.message ?: ""}".trim())
        }
    }


    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as GestionUsuariosApplication)
                val userRepository = application.container.userRepository
                UserViewModel(userRepository = userRepository)
            }
        }
    }
}